function result = method_joint_no_froa_screen(data)
%==========================================================================
% 函数名称：method_joint_no_froa_screen
% 功能说明：
%   联合法的消融版本：
%   不使用 FROA 粗筛，而是直接采用通用粗搜得到的几何初值，
%   然后做 FROA + FDOA 联合精估。
%==========================================================================
tic;
seed_geo = build_common_geo_seed(data);
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];

objfun = @(x) joint_fdoa_froa_cost_function(x, data);
opts = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);


[xhat, fval] = fminsearch(objfun, x0, opts);
elapsed = toc;

result.name = '联合精估-无FROA粗筛';
result.kind = 'joint_no_screen';
result.seed_geo = seed_geo;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'joint');
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end
