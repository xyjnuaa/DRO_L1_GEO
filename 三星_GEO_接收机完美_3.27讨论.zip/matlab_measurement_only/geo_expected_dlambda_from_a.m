function dlambda_deg_day = geo_expected_dlambda_from_a(a_km, const)
%==========================================================================
% 函数名称：geo_expected_dlambda_from_a
% 功能说明：
%   根据两体近似下的平均角速度，计算半长轴对应的 GEO 地固经度漂移率。
%==========================================================================

n_orb = geo_mean_motion_j2(a_km, const);
dlambda_deg_day = (n_orb - const.wE_rad_s) * 86400 * 180 / pi;
end
