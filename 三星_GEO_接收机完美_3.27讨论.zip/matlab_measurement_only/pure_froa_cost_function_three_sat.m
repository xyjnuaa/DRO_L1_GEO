function J = pure_froa_cost_function_three_sat(x, data)
% 三颗观测星下的纯 FROA 目标函数，只优化几何参数 [a, lambda0]
if ~is_valid_radio_state([x(1:2), data.meas.fc_nominal_hz, 0], data)
    J = 1e30;
    return;
end

x_geo = x(1:2);
radio.fc0_hz = data.meas.fc_nominal_hz+3600;
radio.tx_drift_hz_s = 1;
radio.rx1_bias_hz = 0;
radio.rx1_drift_hz_s = 1;
radio.rx2_bias_hz = 0;
radio.rx2_drift_hz_s = 0.95;
radio.rx3_bias_hz = 0;
radio.rx3_drift_hz_s = 1.5;

pred = predict_radio_measurements_three_sat(x_geo, radio, data);
res = (data.z.froa - pred.froa) / data.meas.sigma_froa;
J = sum(res(:).^2);
end
