function result = method_pure_froa_ms(data)
%==========================================================================
% 函数名称：method_pure_froa_ms
% 功能说明：
%   纯 FROA 方法，采用基于 FROA 量测的 Top-K 多起点粗搜。
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates_three_sat(data, 'froa', 5);
objfun = @(x) pure_froa_cost_function_three_sat(x, data);
opts = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',4000, 'MaxIter',2500);

[xhat, fval, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_froa_x0_geom_only(seed_geo, data), objfun, opts);
elapsed = toc;

result.name = '纯FROA';
result.kind = 'froa';
result.seed_geo = best_seed;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'froa', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_froa_x0_geom_only(seed_geo, data)
% FROA 第一阶段只估计几何，因此局部优化初值只保留 [a, lambda0]
unused = data; %#ok<NASGU>
x0 = seed_geo(:).';
end

function x0 = build_froa_x0(seed_geo, data)
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.tx_drift_hz_s];
end
