function result = method_traditional_nondiff_ms(data)
%==========================================================================
% 函数名称：method_traditional_nondiff_ms
% 功能说明：
%   传统非差多普勒法，采用基于非差量测的 Top-K 多起点粗搜。
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates_three_sat(data, 'traditional', 5);
objfun = @(x) traditional_cost_function_three_sat(x, data);
opts = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-8, ...
    'MaxFunEvals',4000, 'MaxIter',2500);

[xhat, fval, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_traditional_x0(seed_geo, data), objfun, opts);
elapsed = toc;

result.name = '传统非差多普勒';
result.kind = 'traditional';
result.seed_geo = best_seed;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_traditional_x0(seed_geo, data)
radio0 = estimate_initial_radio_params_three_sat(seed_geo, data, 'traditional');
x0 = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];
end
