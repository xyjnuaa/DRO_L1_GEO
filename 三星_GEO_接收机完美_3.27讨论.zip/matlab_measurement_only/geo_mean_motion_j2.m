function n_rad_s = geo_mean_motion_j2(a_km, const)
%==========================================================================
% 函数名称：geo_mean_motion_j2
% 功能说明：
%   计算赤道圆轨道在“两体 + J2”近似下的等效平均角速度。
%   该量用于：
%   1) 由半长轴推导 GEO 地固经度漂移率
%   2) 构造与 J2 一致的初始圆轨道速度
%==========================================================================

mu = const.muE_km3s2;
re = const.earth_radius_km;
if isfield(const, 'J2')
    J2 = const.J2;
else
    J2 = 1.08262668e-3;
end

n_rad_s = sqrt(mu / a_km^3 * (1 + 1.5 * J2 * (re / a_km)^2));
end
