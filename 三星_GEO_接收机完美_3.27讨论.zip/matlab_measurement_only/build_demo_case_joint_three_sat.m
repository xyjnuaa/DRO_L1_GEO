function data = build_demo_case_joint_three_sat(Nobs, seed, sigma_dopp_hz)
%==========================================================================
% 函数名称：build_demo_case_joint_three_sat
% 功能说明：
%   构造“三颗观测星 + 一颗非合作 GEO 目标”的统一仿真数据。
%   当前三颗观测星分别为：
%   1) 2:1 DRO
%   2) L1 轨道
%   3) L4 长轨道
%==========================================================================

if nargin < 2 || isempty(seed)
    seed = 1;
end
if nargin < 3 || isempty(sigma_dopp_hz)
    sigma_dopp_hz = 0.05;
end
rng(seed);

const = get_constants();
this_dir = fileparts(mfilename('fullpath'));

obs1 = read_dro_init(fullfile(this_dir, '2：1共振比DRO轨道初值.csv'));
obs2 = read_dro_init(fullfile(this_dir, 'L1轨道.csv'));
obs3 = read_dro_init(fullfile(this_dir, 'L4长轨道.csv'));

T_hours = 12;
dt = 60;
t = (0:dt:T_hours * 3600).';
Nall = numel(t);
if Nobs > Nall
    error('Nobs = %d 超过总历元数 %d，请减小 Nobs。', Nobs, Nall);
end

truth.a = const.geo_a_km + 23.54;
truth.lambda0_deg = 109.6;
truth.dlambda_deg_day = geo_expected_dlambda_deg_day_three_sat(truth.a, const);
truth.inc_deg = 0.05;
truth.ecc = 0.0003;

radio.fc_nominal_hz = 12e9;
radio.fc0_hz = radio.fc_nominal_hz + 3600;
radio.tx_drift_hz_s = 1;
radio.rx1_bias_hz = 0;
radio.rx1_drift_hz_s = 0;%1;
radio.rx2_bias_hz = 0;
radio.rx2_drift_hz_s = 0;%0.95;
radio.rx3_bias_hz = 0;
radio.rx3_drift_hz_s = 0;%1.5;

meas.sigma_dopp_hz = sigma_dopp_hz;
meas.fc_nominal_hz = radio.fc_nominal_hz;

X01 = [obs1.x0; obs1.y0; obs1.z0; obs1.vx0; obs1.vy0; obs1.vz0];
X02 = [obs2.x0; obs2.y0; obs2.z0; obs2.vx0; obs2.vy0; obs2.vz0];
X03 = [obs3.x0; obs3.y0; obs3.z0; obs3.vx0; obs3.vy0; obs3.vz0];

traj1 = propagate_dro_cr3bp(X01, t, const.mu);
traj2 = propagate_dro_cr3bp(X02, t, const.mu);
traj3 = propagate_dro_cr3bp(X03, t, const.mu);

[r1_eci_km, v1_eci_kms] = synodic_to_eci_earthcentered(traj1(:,1:3), traj1(:,4:6), t, const);
[r2_eci_km, v2_eci_kms] = synodic_to_eci_earthcentered(traj2(:,1:3), traj2(:,4:6), t, const);
[r3_eci_km, v3_eci_kms] = synodic_to_eci_earthcentered(traj3(:,1:3), traj3(:,4:6), t, const);

[rT_km, vT_kms] = propagate_geo_simple_physical(truth, t, const);

meas_truth = radio;
meas_truth.sigma_dopp_hz = sigma_dopp_hz;
[z, aux] = generate_measurements_joint_three_sat( ...
    rT_km, vT_kms, ...
    r1_eci_km, v1_eci_kms, ...
    r2_eci_km, v2_eci_kms, ...
    r3_eci_km, v3_eci_kms, ...
    t, meas_truth, const);

obs_span_sec = min(600, t(end));
n_window = floor(obs_span_sec / dt) + 1;
if Nobs > n_window
    error(['当前 dt = %.3f s、固定观测弧长 = %.3f s，' ...
        '可用历元数仅为 %d，无法抽取 Nobs = %d 个互异历元。'], ...
        dt, obs_span_sec, n_window, Nobs);
end

idx = uniform_sample_indices_three_sat(n_window, Nobs);

data.const = const;
data.t = t(idx);
data.meas = meas;
data.truth = truth;
data.truth_radio = radio;

data.r1_eci_km = r1_eci_km(idx,:);
data.v1_eci_kms = v1_eci_kms(idx,:);
data.r2_eci_km = r2_eci_km(idx,:);
data.v2_eci_kms = v2_eci_kms(idx,:);
data.r3_eci_km = r3_eci_km(idx,:);
data.v3_eci_kms = v3_eci_kms(idx,:);

data.rT_km = rT_km(idx,:);
data.vT_kms = vT_kms(idx,:);

data.z = slice_measurement_struct_three_sat(z, idx);
data.aux = slice_measurement_struct_three_sat(aux, idx);
data.z_fdoa = data.z.fdoa_hz;
data.z_froa = data.z.froa;
data.meas.fc_hz = radio.fc0_hz;
data.obs_span_sec = obs_span_sec;

data.meas.sigma_f1 = std(data.z.f1_hz - data.aux.f1_true_hz);
data.meas.sigma_f2 = std(data.z.f2_hz - data.aux.f2_true_hz);
data.meas.sigma_f3 = std(data.z.f3_hz - data.aux.f3_true_hz);
data.meas.sigma_fdoa = std(data.z.fdoa_hz - data.aux.fdoa_true_hz, 0, 'all');
data.meas.sigma_froa = std(data.z.froa - data.aux.froa_true, 0, 'all');

if ~(isfinite(data.meas.sigma_f1) && data.meas.sigma_f1 > 0)
    data.meas.sigma_f1 = sigma_dopp_hz;
end
if ~(isfinite(data.meas.sigma_f2) && data.meas.sigma_f2 > 0)
    data.meas.sigma_f2 = sigma_dopp_hz;
end
if ~(isfinite(data.meas.sigma_f3) && data.meas.sigma_f3 > 0)
    data.meas.sigma_f3 = sigma_dopp_hz;
end
if ~(isfinite(data.meas.sigma_fdoa) && data.meas.sigma_fdoa > 0)
    data.meas.sigma_fdoa = sqrt(2) * sigma_dopp_hz;
end
if ~(isfinite(data.meas.sigma_froa) && data.meas.sigma_froa > 0)
    data.meas.sigma_froa = 1e-9;
end
end

function dlambda_deg_day = geo_expected_dlambda_deg_day_three_sat(a_km, const)
n_orb = geo_mean_motion_j2(a_km, const);
dlambda_deg_day = (n_orb - const.wE_rad_s) * 86400 * 180 / pi;
end

function idx = uniform_sample_indices_three_sat(n_window, Nobs)
idx = zeros(Nobs, 1);
for k = 1:Nobs
    idx(k) = 1 + floor((k - 1) * (n_window - 1) / max(Nobs - 1, 1));
end
idx(end) = n_window;
idx = unique(idx, 'stable');
if numel(idx) ~= Nobs
    error('均匀抽样索引生成失败，请检查 n_window 与 Nobs 设置。');
end
end

function out = slice_measurement_struct_three_sat(in, idx)
names = fieldnames(in);
for i = 1:numel(names)
    out.(names{i}) = in.(names{i})(idx,:);
end
end
