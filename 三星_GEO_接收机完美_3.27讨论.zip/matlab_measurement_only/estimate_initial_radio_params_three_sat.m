function radio0 = estimate_initial_radio_params_three_sat(seed_geo, data, mode_name)
%==========================================================================
% 在三颗观测星配置下，根据固定几何参数生成发射源频率参数初值
%==========================================================================

geom = predict_radio_measurements_three_sat(seed_geo, zero_radio_three_sat(), data);
t = data.t(:);
D1 = geom.f1_hz(:);
D2 = geom.f2_hz(:);
D3 = geom.f3_hz(:);

switch lower(mode_name)
    case 'traditional'
        H = [D1; D2; D3];
        H = [H, H .* [t; t; t]];
        y = [data.z.f1_hz(:); data.z.f2_hz(:); data.z.f3_hz(:)];
        theta = H \ y;

    case 'fdoa'
        Hd12 = [D1 - D2, (D1 - D2) .* t];
        Hd13 = [D1 - D3, (D1 - D3) .* t];
        Hd = [Hd12; Hd13];
        yd = [data.z.fdoa_hz(:,1); data.z.fdoa_hz(:,2)];
        theta = Hd \ yd;

    case 'joint'
        Havg = [D1; D2; D3];
        Havg = [Havg, Havg .* [t; t; t]];
        yavg = [data.z.f1_hz(:); data.z.f2_hz(:); data.z.f3_hz(:)];
        theta_avg = Havg \ yavg;

        Hd12 = [D1 - D2, (D1 - D2) .* t];
        Hd13 = [D1 - D3, (D1 - D3) .* t];
        Hd = [Hd12; Hd13];
        yd = [data.z.fdoa_hz(:,1); data.z.fdoa_hz(:,2)];
        theta_d = Hd \ yd;

        theta = 0.5 * (theta_avg + theta_d);

    otherwise
        error('未知的初值模式：%s', mode_name);
end

radio0.fc0_hz = theta(1);
radio0.tx_drift_hz_s = theta(2);
radio0.rx1_bias_hz = 0;
radio0.rx1_drift_hz_s = 0;
radio0.rx2_bias_hz = 0;
radio0.rx2_drift_hz_s = 0;
radio0.rx3_bias_hz = 0;
radio0.rx3_drift_hz_s = 0;
end

function radio = zero_radio_three_sat()
radio.fc0_hz = 1;
radio.tx_drift_hz_s = 0;
radio.rx1_bias_hz = 0;
radio.rx1_drift_hz_s = 0;
radio.rx2_bias_hz = 0;
radio.rx2_drift_hz_s = 0;
radio.rx3_bias_hz = 0;
radio.rx3_drift_hz_s = 0;
end
