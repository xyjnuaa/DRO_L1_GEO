function a_kmps2 = geo_accel_j2(r_km, const)
%==========================================================================
% 函数名称：geo_accel_j2
% 功能说明：
%   计算地球引力场在“两体 + J2”模型下的惯性系加速度。
%==========================================================================

x = r_km(1);
y = r_km(2);
z = r_km(3);

r2 = x^2 + y^2 + z^2;
r = sqrt(r2);

mu = const.muE_km3s2;
re = const.earth_radius_km;
if isfield(const, 'J2')
    J2 = const.J2;
else
    J2 = 1.08262668e-3;
end

z2_r2 = z^2 / r2;
k = 1.5 * J2 * (re / r)^2;

ax = -mu * x / r^3 * (1 - k * (5 * z2_r2 - 1));
ay = -mu * y / r^3 * (1 - k * (5 * z2_r2 - 1));
az = -mu * z / r^3 * (1 - k * (5 * z2_r2 - 3));

a_kmps2 = [ax; ay; az];
end
