function [r_km, v_kms] = propagate_geo_from_x_physical(x, t_sec, const)
%==========================================================================
% 函数名称：propagate_geo_from_x_physical
% 功能说明：
%   根据当前待估几何参数传播候选 GEO 轨道。
%
% 输入：
%   x = [a_km, lambda0_deg]，若传入更长向量，也只取前两项。
%==========================================================================

truth.a = x(1);
truth.lambda0_deg = x(2);
truth.dlambda_deg_day = geo_expected_dlambda_from_a(x(1), const);
truth.inc_deg = 0;
truth.ecc = 0;
[r_km, v_kms] = propagate_geo_simple_physical(truth, t_sec, const);
end
