function result = method_froa_nondiff_measurement_driven_grid(data)
%==========================================================================
% 函数名称：method_froa_nondiff_measurement_driven_grid
% 功能说明：
%   FROA + 非差联合法的增强版本：
%   1) 先用 FROA 进行几何粗搜与局部优化，得到中间解
%   2) 再以该中间解为中心，先做一轮小范围二维细搜
%   3) 最后从细搜结果直接启动一次非差局部优化
%   4) 取该结果作为最终输出
%
% 设计目的：
%   让第二阶段非差多普勒不只是补载频，而是有机会继续修正几何参数。
%==========================================================================
tic;

%--------------------------------------------------------------------------
% 第一步：基于 FROA 的粗搜与局部优化
%--------------------------------------------------------------------------
[seed_list, ~] = build_geo_seed_candidates_three_sat(data, 'froa', 5);

opts_froa = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',4000, 'MaxIter',2500);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

[x_mid, ~, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_froa_stage_x0_geom_only(seed_geo, data), ...
    @(x) pure_froa_cost_function_three_sat(x, data), opts_froa);

%--------------------------------------------------------------------------
% 第二步：围绕 FROA 中间解做小范围二维细搜
% 用非差代价先筛出一个更适合第二阶段局部优化的几何初值。
%--------------------------------------------------------------------------
geo_mid = x_mid(1:2);
geo_refined = refine_geo_by_local_grid_grid(geo_mid, data);
geo_refined =geo_mid;%不让非差再改变几何

%--------------------------------------------------------------------------
% 第三步：从细搜结果直接启动一次非差局部优化
% 这里不再构造细搜后的邻域多初值，避免流程继续复杂化。
%--------------------------------------------------------------------------
[xhat_best, fval_best] = solve_radio_with_fixed_geo_froa_nd(geo_refined, data);

elapsed = toc;

result.name = 'FROA+非差联合法';
result.kind = 'froa_nondiff';
result.name = 'FROA+非差联合法';
result.seed_geo = best_seed;
result.geo_refined = geo_refined;
result.stage2_seed_geo = geo_refined;
result.x_mid = x_mid;
result.xhat = xhat_best;
result.est = unpack_estimate_vector(xhat_best, 'traditional', data);
result.fval = fval_best;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_froa_stage_x0_geom_only(seed_geo, data)
% FROA 第一阶段只负责给出几何中间解，因此初值只保留几何参数
unused = data; %#ok<NASGU>
x0 = seed_geo(:).';
end

function J = local_traditional_cost_froa_nd_grid_geom_only(x, data, x_center)
% 第二阶段局部代价函数：
% 1) 以传统非差多普勒代价为主
% 2) 允许几何在较宽邻域内搜索
% 3) 不再使用第一阶段频漂量作为约束，因为 FROA 第一阶段已不估计频漂
if any(abs(x(1:2) - x_center(1:2)) > [150, 1.5])
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);
J = J + 0.001 * sum(((x(1:2) - x_center(1:2)) ./ [40, 0.4]).^2);
end

function [xhat, fval] = solve_radio_with_fixed_geo_froa_nd(geo_fixed, data)
% 在固定 FROA 几何解的前提下，仅利用非差多普勒回代载频与频漂。
% 这样可以避免第二阶段非差再次调整几何，从而破坏第一阶段
% 已经获得的几何精度。
radio_hat = estimate_initial_radio_params_three_sat(geo_fixed, data, 'traditional');
xhat = [geo_fixed(:).', radio_hat.fc0_hz, radio_hat.tx_drift_hz_s];
fval = traditional_cost_function_three_sat(xhat, data);
end

function x0 = build_froa_stage_x0_grid(seed_geo, data)
% FROA 阶段的局部优化初值：几何 + 发射机频漂
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.tx_drift_hz_s];
end

function geo_best = refine_geo_by_local_grid_grid(geo_center, data)
%--------------------------------------------------------------------------
% 以 FROA 中间解为中心做一轮小范围二维细搜。
% 半长轴和经度都做局部离散搜索，再用非差代价选最优几何。
%--------------------------------------------------------------------------
a_center = geo_center(1);
lambda_center = geo_center(2);

a_grid = a_center + (-30:2:30);
lambda_grid = lambda_center + (-0.30:0.05:0.30);

best_cost = inf;
geo_best = geo_center;

for ia = 1:numel(a_grid)
    for il = 1:numel(lambda_grid)
        geo_try = [a_grid(ia), lambda_grid(il)];
        radio_try = estimate_initial_radio_params_three_sat(geo_try, data, 'traditional');
        x_try = [geo_try, radio_try.fc0_hz, radio_try.tx_drift_hz_s];
        cost_try = traditional_cost_function_three_sat(x_try, data);

        if cost_try < best_cost
            best_cost = cost_try;
            geo_best = geo_try;
        end
    end
end
end

function J = local_traditional_cost_froa_nd_grid(x, data, x_center)
%--------------------------------------------------------------------------
% 第二阶段局部代价函数：
%   1) 以传统非差多普勒代价为主
%   2) 允许几何在较宽邻域内搜索
%   3) 只保留较弱的软约束，避免完全被 FROA 中间解锁死
%--------------------------------------------------------------------------
if any(abs(x(1:2) - x_center(1:2)) > [150, 1.5])
    J = 1e30;
    return;
end
if abs(x(4) - x_center(3)) > 0.08
    J = 1e30;
    return;
end

J = traditional_cost_function_three_sat(x, data);
J = J + 0.001 * sum(((x(1:2) - x_center(1:2)) ./ [40, 0.4]).^2);
end
