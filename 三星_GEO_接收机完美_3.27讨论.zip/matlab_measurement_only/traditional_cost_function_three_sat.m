function J = traditional_cost_function_three_sat(x, data)
% 三颗观测星下的传统非差多普勒目标函数
if ~is_valid_radio_state(x(1:4), data)
    J = 1e30;
    return;
end

x_geo = x(1:2);
radio.fc0_hz = x(3);
radio.tx_drift_hz_s = x(4);
radio.rx1_bias_hz = 0;
radio.rx1_drift_hz_s = 1;
radio.rx2_bias_hz = 0;
radio.rx2_drift_hz_s = 0.95;
radio.rx3_bias_hz = 0;
radio.rx3_drift_hz_s = 1.5;

pred = predict_radio_measurements_three_sat(x_geo, radio, data);
r1 = (data.z.f1_hz - pred.f1_hz) / data.meas.sigma_f1;
r2 = (data.z.f2_hz - pred.f2_hz) / data.meas.sigma_f2;
r3 = (data.z.f3_hz - pred.f3_hz) / data.meas.sigma_f3;

J = sum(r1.^2) + sum(r2.^2) + sum(r3.^2);
J = J + (x(4) / 0.05)^2;
end
