function result = method_pure_fdoa_ms(data)
%==========================================================================
% 函数名称：method_pure_fdoa_ms
% 功能说明：
%   纯 FDOA 方法，采用基于 FDOA 量测的 Top-K 多起点粗搜。
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates_three_sat(data, 'fdoa', 5);
objfun = @(x) pure_fdoa_cost_function_three_sat(x, data);
opts = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-8, ...
    'MaxFunEvals',2500, 'MaxIter',1800);

[xhat, fval, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_fdoa_x0(seed_geo, data), objfun, opts);
elapsed = toc;

result.name = '纯FDOA';
result.kind = 'fdoa';
result.seed_geo = best_seed;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'fdoa', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_fdoa_x0(seed_geo, data)
radio0 = estimate_initial_radio_params_three_sat(seed_geo, data, 'fdoa');
x0 = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];
end
