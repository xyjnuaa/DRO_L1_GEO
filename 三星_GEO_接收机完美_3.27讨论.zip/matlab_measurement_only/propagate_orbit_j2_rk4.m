function [r_km, v_kms] = propagate_orbit_j2_rk4(r0_km, v0_kms, t_sec, const)
%==========================================================================
% 函数名称：propagate_orbit_j2_rk4
% 功能说明：
%   使用固定步长 RK4 对“两体 + J2”动力学进行数值积分。
%
% 说明：
%   1) 输出时刻可以是不等间隔的
%   2) 内部会把每个输出间隔自动细分到不超过 20 s
%   3) 相比通用 ODE 求解器，这里更轻量，适合在代价函数中频繁调用
%==========================================================================

t_query = t_sec(:);
prepend_zero = isempty(t_query) || (t_query(1) ~= 0);
if prepend_zero
    t_work = [0; t_query];
else
    t_work = t_query;
end

Nw = numel(t_work);
r_work = zeros(Nw, 3);
v_work = zeros(Nw, 3);

y = [r0_km(:); v0_kms(:)];
r_work(1, :) = y(1:3).';
v_work(1, :) = y(4:6).';

for k = 2:Nw
    dt_total = t_work(k) - t_work(k - 1);
    n_sub = max(1, ceil(abs(dt_total) / 20));
    h = dt_total / n_sub;

    for i = 1:n_sub
        y = rk4_step(y, h, const);
    end

    r_work(k, :) = y(1:3).';
    v_work(k, :) = y(4:6).';
end

if prepend_zero
    r_km = r_work(2:end, :);
    v_kms = v_work(2:end, :);
else
    r_km = r_work;
    v_kms = v_work;
end
end

function y_next = rk4_step(y, h, const)
k1 = orbit_rhs(y, const);
k2 = orbit_rhs(y + 0.5 * h * k1, const);
k3 = orbit_rhs(y + 0.5 * h * k2, const);
k4 = orbit_rhs(y + h * k3, const);
y_next = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4);
end

function dy = orbit_rhs(y, const)
r = y(1:3);
v = y(4:6);
a = geo_accel_j2(r, const);
dy = [v; a];
end
