function tf = is_valid_radio_state(x4, data)
% 判断 GEO 参数与发射源参数是否落在合理范围内。

a = x4(1);
lambda0_deg = x4(2);
fc0_hz = x4(3);
tx_drift_hz_s = x4(4);

tf = true;

if a < data.const.geo_a_km - 1500 || a > data.const.geo_a_km + 1500
    tf = false;
    return;
end
if lambda0_deg < 0 || lambda0_deg > 360
    tf = false;
    return;
end
if fc0_hz < data.meas.fc_nominal_hz - 2e9 || fc0_hz > data.meas.fc_nominal_hz + 2e9
    tf = false;
    return;
end
if abs(tx_drift_hz_s) > 100
    tf = false;
end
end
