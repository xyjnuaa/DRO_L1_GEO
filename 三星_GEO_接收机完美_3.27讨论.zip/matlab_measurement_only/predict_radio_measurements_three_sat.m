function pred = predict_radio_measurements_three_sat(x_geo, radio_param, data)
%==========================================================================
% 在三颗观测星配置下预测非差频率、FDOA 与 FROA
%==========================================================================

[rT_km, vT_kms] = propagate_geo_from_x_physical(x_geo, data.t, data.const);
N = numel(data.t);
c = data.const.c_km_s;

f1_hz = zeros(N,1);
f2_hz = zeros(N,1);
f3_hz = zeros(N,1);
rhodot1_kms = zeros(N,1);
rhodot2_kms = zeros(N,1);
rhodot3_kms = zeros(N,1);

for k = 1:N
    rho1_vec = rT_km(k,:) - data.r1_eci_km(k,:);
    u1 = rho1_vec / norm(rho1_vec);
    rhodot1_kms(k) = u1 * (vT_kms(k,:) - data.v1_eci_kms(k,:)).';

    rho2_vec = rT_km(k,:) - data.r2_eci_km(k,:);
    u2 = rho2_vec / norm(rho2_vec);
    rhodot2_kms(k) = u2 * (vT_kms(k,:) - data.v2_eci_kms(k,:)).';

    rho3_vec = rT_km(k,:) - data.r3_eci_km(k,:);
    u3 = rho3_vec / norm(rho3_vec);
    rhodot3_kms(k) = u3 * (vT_kms(k,:) - data.v3_eci_kms(k,:)).';

    tx_freq_hz = radio_param.fc0_hz + radio_param.tx_drift_hz_s * data.t(k);
    f1_hz(k) = tx_freq_hz * (1 - rhodot1_kms(k) / c);
    f2_hz(k) = tx_freq_hz * (1 - rhodot2_kms(k) / c);
    f3_hz(k) = tx_freq_hz * (1 - rhodot3_kms(k) / c);
end

pred.r_km = rT_km;
pred.v_kms = vT_kms;
pred.rhodot1_kms = rhodot1_kms;
pred.rhodot2_kms = rhodot2_kms;
pred.rhodot3_kms = rhodot3_kms;
pred.f1_hz = f1_hz;
pred.f2_hz = f2_hz;
pred.f3_hz = f3_hz;
pred.fdoa_hz = [f1_hz - f2_hz, f1_hz - f3_hz];
pred.froa = [f1_hz ./ f2_hz, f1_hz ./ f3_hz];
end
