# GEO非合作目标初轨确定测量体制对比报告

## 1. 研究背景与目标

本项目面向“非合作目标 GEO 初轨确定”问题，研究在仅依赖空间多普勒相关测量的条件下，如何联合两颗地月空间观测星对 GEO 目标进行轨道与频率参数估计。当前代码重点比较以下问题：

1. 在未知目标真实发射载频 `fc` 的情况下，是否仍可完成 GEO 初轨确定。
2. 传统非差多普勒、纯 FDOA、纯 FROA、FROA 预筛选联合估计、三阶段融合法等方案的性能差异如何。
3. 接收机时钟完美时，不同方法在几何参数估计和载频估计之间的优势与局限分别是什么。

本报告基于当前工作目录中的 MATLAB 实现与 `run_monte_carlo_measurement_compare.m` 生成的结果文件 `monte_carlo_measurement_compare_results.mat` 编写。

---

## 2. 场景设置与建模假设

### 2.1 总体场景

两颗观测星分别位于：

1. `2：1共振比DRO轨道初值.csv` 对应的 2:1 DRO 轨道；
2. `L1轨道.csv` 对应的 L1 Halo 轨道。

观测目标为一颗 GEO 非合作目标。代码中采用简化 GEO 动力学模型，目标状态由以下参数表征：

- 半长轴 `a`
- 初始经度 `lambda0`
- 经度漂移率 `dlambda`

同时引入发射源频率参数：

- 发射源初始载频 `fc0`
- 发射源频漂 `tx_drift`

当前版本在方法求解中采用“接收机时钟完美”假设，即：

- 接收机频偏 = 0
- 接收机频漂 = 0

因此所有方法最终只需要估计 GEO 几何参数与发射源频率参数。

### 2.2 当前仿真配置

依据 [build_demo_case_joint.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\build_demo_case_joint.m)，当前主要配置为：

- 总仿真时长：`T_hours = 12`
- 采样间隔：`dt = 60 s`
- Monte Carlo 历元数列表：`N_list = [5, 10]`
- Monte Carlo 次数：`MC = 20`
- 单路频率测量噪声标准差：`sigma_dopp_hz = 0.95 Hz`

真值 GEO 参数设置为：

- `a = geo_a_km + 20 km`
- `lambda0 = 110.0 deg`
- `dlambda = 0.08 deg/day`
- `inc = 0.05 deg`
- `ecc = 0.0003`

真值发射源频率参数设置为：

- 名义载频：`12 GHz`
- 实际初始载频：`fc0 = 12 GHz + 3600 Hz`
- 发射源频漂：`0.2 Hz/s`

---

## 3. 轨道动力学模型

### 3.1 观测星动力学模型

依据 [propagate_dro_cr3bp.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\propagate_dro_cr3bp.m)，观测星在地月圆限制三体问题（CR3BP）旋转系中传播。其主要特点为：

- 动力学模型采用标准 CR3BP 方程；
- 初始状态由 CSV 文件提供；
- 传播积分器为 `ode113`；
- 积分容差为：
  - `RelTol = 1e-11`
  - `AbsTol = 1e-12`

### 3.2 坐标转换模型

依据 [synodic_to_eci_earthcentered.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\synodic_to_eci_earthcentered.m)，将地月旋转系无量纲状态转换到地心惯性系 ECI。主要处理包括：

1. 旋转系到惯性系旋转；
2. 加入角速度项 `Omega x r` 完成速度转换；
3. 将原点从地月质心平移到地心。

### 3.3 GEO目标动力学模型

依据 [propagate_geo_simple.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\propagate_geo_simple.m)，GEO 目标采用简化近圆近赤道模型：

- 目标轨道位于赤道平面；
- 假设轨道近圆；
- 通过经度漂移率描述相对地球自转的偏差。

设地球自转角速度为 `wE`，用户给定的漂移率转换为 `extra`，则等效惯性角速度为：

`n_eff = wE + extra`

轨道相位为：

`phi(t) = phi0 + n_eff * t`

因此目标位置与速度近似为：

`r(t) = a [cos(phi), sin(phi), 0]`

`v(t) = a * n_eff [-sin(phi), cos(phi), 0]`

该模型适合作为测量体制比较与原理验证的简化模型，但不代表高保真 GEO 摄动模型。

---

## 4. 测量模型

### 4.1 单路非差多普勒模型

依据 [generate_measurements_joint.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\generate_measurements_joint.m)，对第 `i` 条观测链路，接收频率模型为：

`f_i(t) = f_tx(t) * (1 - rhodot_i / c) + noise`

其中：

- `f_tx(t) = fc0 + tx_drift * t`
- `rhodot_i` 为目标相对于第 `i` 颗观测星的径向速度
- `c` 为光速

在当前代码配置中，由于接收机频偏/频漂真值设为 0，故未保留接收机附加项。

### 4.2 FDOA测量

`FDOA = f1 - f2`

FDOA 对共同频率项的绝对量级不如非差多普勒敏感，但对两条观测链路的几何差异敏感。

### 4.3 FROA测量

`FROA = f1 / f2`

FROA 为无量纲比值量，其特点是：

- 对共同载频幅值不敏感；
- 更偏向于约束几何结构关系；
- 数值上对噪声与模型偏差较敏感。

### 4.4 噪声模型

测量噪声假设为高斯白噪声，仅加入在单路频率量测中：

`f1_meas = f1_true + n1`

`f2_meas = f2_true + n2`

其中：

- `n1, n2 ~ N(0, sigma_dopp_hz^2)`
- 当前 Monte Carlo 中 `sigma_dopp_hz = 0.95 Hz`

---

## 5. 参数与约束

### 5.1 待估参数

根据方法不同，当前代码中涉及的参数子集如下：

1. 几何参数：
   - `a`
   - `lambda0`
   - `dlambda`
2. 频率参数：
   - `fc0`
   - `tx_drift`

### 5.2 参数边界

依据 [is_valid_radio_state.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\is_valid_radio_state.m)，主要约束包括：

- `a` 在理想 GEO 半长轴附近 `±1500 km`
- `lambda0` 在 `[0, 360] deg`
- `|dlambda| <= 3 deg/day`
- `fc0` 在名义载频附近 `±2 MHz`
- `|tx_drift| <= 2 Hz/s`

### 5.3 成功判据

依据 [extract_estimation_metrics.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\extract_estimation_metrics.m)，当前成功判据为：

- 最大位置误差 `< 100 km`
- 半长轴误差 `< 50 km`
- 初始经度误差 `< 0.5 deg`

---

## 6. 粗搜索策略

### 6.1 通用粗搜索

依据 [build_common_geo_seed.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\build_common_geo_seed.m)，通用粗搜索使用非差多普勒残差作为评分：

- `a_grid = geo_a + (-1200:75:1200) km`
- `lambda_grid = 88:2:132 deg`
- `dlambda_grid = -0.10:0.02:0.14 deg/day`

对每个候选几何参数，先线性回代频率参数，再比较两路绝对频率残差平方和，取最优点作为初值。

### 6.2 FROA粗筛

依据 [build_froa_screen_seed.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\build_froa_screen_seed.m)，FROA 粗筛使用相同网格，但以 FROA 残差作为评分。

该策略的设计目的不是直接给出最终解，而是为联合法/融合法提供一个偏向几何关系的初始种子。

---

## 7. 各方法说明

### 7.1 传统非差多普勒法

实现文件：[method_traditional_nondiff.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_traditional_nondiff.m)

特点：

- 使用通用粗搜索初始化；
- 目标函数为两路绝对频率残差平方和；
- 待估参数为 `[a, lambda0, dlambda, fc0, tx_drift]`；
- 理论上对绝对载频最敏感。

目标函数实现见 [traditional_cost_function.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\traditional_cost_function.m)。

### 7.2 纯FDOA法

实现文件：[method_pure_fdoa.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_pure_fdoa.m)

特点：

- 使用通用粗搜索初始化；
- 仅使用 `f1-f2` 差分频率；
- 待估参数仍为 `[a, lambda0, dlambda, fc0, tx_drift]`；
- 对几何差异较敏感，对绝对载频敏感性弱。

目标函数实现见 [pure_fdoa_cost_function.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\pure_fdoa_cost_function.m)。

### 7.3 纯FROA法

实现文件：[method_pure_froa.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_pure_froa.m)

特点：

- 使用通用粗搜索初始化；
- 仅使用 `f1/f2`；
- 不直接估计 `fc0`，主要估计几何参数与发射源频漂；
- 对共同载频幅值不敏感，因此很难单独用于精确估计载频。

目标函数实现见 [pure_froa_cost_function.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\pure_froa_cost_function.m)。

### 7.4 FROA筛选+联合精估

实现文件：[method_froa_screen_then_fdoa.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_froa_screen_then_fdoa.m)

流程：

1. 先用 FROA 粗筛得到几何初值；
2. 再做 FROA+FDOA 联合局部优化。

联合目标函数见 [joint_fdoa_froa_cost_function.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\joint_fdoa_froa_cost_function.m)，其形式为：

`J = sum(rD^2) + 0.6 * sum(rR^2) + regularization`

其中：

- `rD` 为 FDOA 归一化残差；
- `rR` 为 FROA 归一化残差；
- `0.6` 为 FROA 权重。

### 7.5 三阶段融合法

实现文件：[method_hybrid_fusion.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_hybrid_fusion.m)

流程：

1. 用 FROA 粗筛获取几何初值；
2. 用 FROA+FDOA 做中间联合估计；
3. 固定在中间解附近，用非差多普勒回代载频并做最终局部微调。

该方法的设计目标是：

- 前端利用 FROA/FDOA 提供几何约束；
- 后端利用非差多普勒对绝对载频的高敏感性改善 `fc0` 与 `tx_drift` 的估计。

### 7.6 联合精估-无FROA粗筛

实现文件：[method_joint_no_froa_screen.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_joint_no_froa_screen.m)

用途：

- 作为消融版本；
- 用于检验“FROA 粗筛”本身是否对联合法性能有关键贡献。

### 7.7 三阶段融合-无FROA粗筛

实现文件：[method_hybrid_fusion_no_froa_screen.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\method_hybrid_fusion_no_froa_screen.m)

用途：

- 作为三阶段融合法的消融版本；
- 用于比较“有无 FROA 粗筛”对最终融合性能的影响。

---

## 8. Monte Carlo实验设置

依据 [run_monte_carlo_measurement_compare.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\run_monte_carlo_measurement_compare.m)，当前 Monte Carlo 实验设置为：

- `Nobs = [5, 10]`
- `MC = 20`
- `sigma_dopp_hz = 0.95 Hz`

统计量包括：

- 最大位置误差均值
- 成功率
- 平均耗时
- 半长轴误差均值
- 初始经度误差均值
- 经度漂移率误差均值
- 发射源初始载频误差均值
- 发射源频漂误差均值

---

## 9. 实验结果

### 9.1 Nobs = 5 时的均值结果

| 方法 | 最大位置误差均值 km | 成功率 | 平均耗时 s | 半长轴误差 km | 初始经度误差 deg | 载频误差 Hz | 频漂误差 Hz/s |
|---|---:|---:|---:|---:|---:|---:|---:|
| 传统非差多普勒 | 1110.20 | 0.00 | 1.2275 | 451.98 | 1.3692 | 140.05 | 0.1907 |
| 纯FDOA | 653.98 | 0.55 | 1.1319 | 267.00 | 0.8000 | 5.84e6 | 1.64e4 |
| 纯FROA | 653.98 | 0.55 | 1.1319 | 267.00 | 0.8000 | NaN | 8.19e3 |
| FROA筛选+联合精估 | 734.08 | 0.50 | 1.1136 | 298.75 | 0.9000 | 2.74e6 | 7.86e3 |
| 三阶段融合法 | 734.08 | 0.50 | 1.1139 | 298.75 | 0.9000 | 127.95 | 0.1237 |
| 联合精估-无FROA粗筛 | 653.98 | 0.55 | 1.1332 | 267.00 | 0.8000 | 2.92e6 | 8.19e3 |
| 三阶段融合-无FROA粗筛 | 653.98 | 0.55 | 1.1314 | 267.00 | 0.8000 | 115.69 | 0.1100 |

### 9.2 Nobs = 10 时的均值结果

| 方法 | 最大位置误差均值 km | 成功率 | 平均耗时 s | 半长轴误差 km | 初始经度误差 deg | 载频误差 Hz | 频漂误差 Hz/s |
|---|---:|---:|---:|---:|---:|---:|---:|
| 传统非差多普勒 | 705.01 | 0.00 | 1.7918 | 295.88 | 0.8653 | 58.77 | 0.1204 |
| 纯FDOA | 20.00 | 1.00 | 1.6807 | 20.00 | 0.0000 | 5.22e6 | 9.78e3 |
| 纯FROA | 20.00 | 1.00 | 1.6726 | 20.00 | 0.0000 | NaN | 4.89e3 |
| FROA筛选+联合精估 | 20.00 | 1.00 | 1.6595 | 20.00 | 0.0000 | 2.62e6 | 4.90e3 |
| 三阶段融合法 | 20.00 | 1.00 | 1.6498 | 20.00 | 0.0000 | 28.34 | 0.0011 |
| 联合精估-无FROA粗筛 | 20.00 | 1.00 | 1.6684 | 20.00 | 0.0000 | 2.61e6 | 4.89e3 |
| 三阶段融合-无FROA粗筛 | 20.00 | 1.00 | 1.6710 | 20.00 | 0.0000 | 31.99 | 0.0014 |

---

## 10. 结果分析

### 10.1 非差多普勒的优势与问题

传统非差多普勒在载频估计上表现最好，尤其在当前接收机时钟完美的假设下，这一结果具有明确物理意义：

- 非差多普勒直接使用 `f1` 与 `f2` 的绝对频率信息；
- 因而对 `fc0` 的敏感性最强；
- 相比 FDOA/FROA，其对绝对载频的可观性更高。

但在当前实验配置下，传统非差多普勒的几何收敛性能并不占优，尤其在 `Nobs=5` 与 `Nobs=10` 下，最大位置误差与成功率均不理想。

### 10.2 纯FDOA与纯FROA的特点

纯 FDOA 与纯 FROA 在几何参数上能够快速收敛到接近真值的轨道参数，尤其在 `Nobs=10` 时：

- 半长轴误差约为 `20 km`
- 初始经度误差约为 `0 deg`
- 成功率达到 `1`

但它们对绝对载频估计能力较弱：

- 纯 FDOA 载频误差仍在 `10^6 Hz` 量级；
- 纯 FROA 甚至不直接输出 `fc0`。

这说明：

- FDOA/FROA 更适合提供几何约束；
- 单独依赖它们难以精确恢复绝对载频。

### 10.3 联合法的作用

FROA+FDOA 联合法在当前实现中可以提升相对于纯 FDOA 的部分频率估计表现，但对 `fc0` 的提升仍有限。原因包括：

1. FROA 主要补充几何结构信息，而不是强力锁定绝对载频；
2. 联合代价函数中 FROA 权重设置为 `0.6`，其本质仍然是几何辅助项；
3. 在接收机完美时钟的设定下，绝对载频最强的信息来源仍是非差多普勒。

### 10.4 三阶段融合法的意义

三阶段融合法是当前代码中最有工程意义的方案，其表现为：

1. 在几何上保持与联合法同一量级；
2. 在载频与频漂估计上显著优于纯 FDOA、纯 FROA 与联合法；
3. 在 `Nobs=10` 时，载频误差约为 `28.34 Hz`，已接近传统非差多普勒的 `58.77 Hz`，甚至更优于当前这一组 Monte Carlo 均值结果；
4. 在 `Nobs=5` 时，载频误差约为 `127.95 Hz`，同样远优于其他差分/比值类方法。

这说明三阶段设计是合理的：

- 前端依赖 FROA/FDOA 提供几何约束；
- 后端依赖非差多普勒恢复绝对频率参数；
- 最终通过局部微调兼顾几何和频率两类信息。

### 10.5 关于FROA粗筛的消融结论

由“有无 FROA 粗筛”的成对对比可见：

- `combo` 与 `joint_noscreen` 的几何结果接近；
- `fusion` 与 `fusion_noscreen` 的结果也非常接近；

说明在当前参数设置和粗搜索网格下，FROA 粗筛对最终结果的影响有限。也就是说：

- 当前性能差异主要来自后端测量体制和融合方式；
- 而不是前端是否采用 FROA 粗筛。

---

## 11. 当前模型与实验的局限性

### 11.1 GEO动力学模型较简化

当前 GEO 传播仅采用近圆近赤道模型，未考虑：

- 地球非球形摄动
- 日月引力摄动
- SRP 等高阶因素

因此当前结果适合作为“测量体制与算法结构”的对比验证，而不宜直接视作高保真工程精度。

### 11.2 采样方式会影响可观性

当前实现中只保留前 `Nobs` 个历元，即：

`idx = 1:Nobs`

因此当采样间隔 `dt` 改变时，实际比较的不仅是采样密度，还会改变总观测弧长。该问题会显著影响 FROA/FDOA 类方法的几何可观性。

### 11.3 优化器仍为局部搜索

当前方法主要使用 `fminsearch`，存在以下问题：

- 易受初值影响；
- 容易陷入局部极小值；
- 当粗搜索网格变粗时，结果稳定性会明显下降。

---

## 12. 结论

基于当前模型、配置与 Monte Carlo 结果，可以得到以下结论：

1. 在接收机时钟完美的假设下，传统非差多普勒法对绝对载频 `fc0` 的估计最敏感，具有天然优势。
2. 纯 FDOA 与纯 FROA 更适合提供几何约束，但单独用于载频估计时性能明显不足。
3. FROA+FDOA 联合法可作为几何估计前端，但其对绝对载频的提升有限。
4. 三阶段融合法在当前实验中体现出最好的折中性能：在保持几何解较优的同时，大幅改善了载频和频漂估计。
5. FROA 粗筛在当前配置下并不是决定性因素，后端测量体制与参数回代策略更关键。

---

## 13. 后续建议

建议下一步重点开展以下工作：

1. 将“固定前 `Nobs` 个点”改为“固定观测弧长后均匀抽样”，使不同 `dt` 的比较更公平。
2. 将粗搜索扩展为“多分辨率 + Top-K 多起点”策略，降低局部极小值风险。
3. 尝试将 FROA 比值量改写为对数形式或更稳定的归一化表达，提高联合优化数值稳定性。
4. 在保持接收机完美时钟假设的同时，逐步恢复接收机偏差项，研究方法对更真实场景的鲁棒性。
5. 若后续目标是论文表达，建议把三阶段融合法作为主推方案，并将联合法、无粗筛消融版作为辅助对比。

---

## 14. 代码与结果文件索引

主要模型与实验脚本：

- [build_demo_case_joint.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\build_demo_case_joint.m)
- [generate_measurements_joint.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\generate_measurements_joint.m)
- [propagate_dro_cr3bp.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\propagate_dro_cr3bp.m)
- [propagate_geo_simple.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\propagate_geo_simple.m)
- [run_monte_carlo_measurement_compare.m](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\run_monte_carlo_measurement_compare.m)

结果文件：

- [monte_carlo_measurement_compare_results.mat](G:\侦察卫星弱信号方面\初轨确定\3_19\matlab_measurement_only\monte_carlo_measurement_compare_results.mat)

