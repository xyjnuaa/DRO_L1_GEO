function [radio, info] = solve_reduced_radio_params(x_geo, data, mode_name)
%==========================================================================
% 函数名称：solve_reduced_radio_params
% 功能说明：
%   在几何参数 [a, lambda0] 固定时，利用线性最小二乘解析回代
%   发射源初始载频 fc0 和频漂 tx_drift。
%   这样外层优化只需要处理几何参数，可减少几何与频参之间的耦合。
%
% mode_name:
%   'traditional' - 基于两路非差频率 f1、f2 回代
%   'fdoa'        - 基于 FDOA 回代
%==========================================================================

geom = predict_radio_measurements(x_geo, unit_radio(), data);
t = data.t(:);
s1 = geom.f1_hz(:);
s2 = geom.f2_hz(:);

switch lower(mode_name)
    case 'traditional'
        A = [ ...
            s1 / data.meas.sigma_f1,           (s1 .* t) / data.meas.sigma_f1; ...
            s2 / data.meas.sigma_f2,           (s2 .* t) / data.meas.sigma_f2; ...
            0,                                 1 / 0.05];
        b = [ ...
            data.z.f1_hz(:) / data.meas.sigma_f1; ...
            data.z.f2_hz(:) / data.meas.sigma_f2; ...
            0];

    case 'fdoa'
        sd = s1 - s2;
        A = [ ...
            sd / data.meas.sigma_fdoa,         (sd .* t) / data.meas.sigma_fdoa; ...
            0,                                 1 / 0.05];
        b = [ ...
            data.z.fdoa_hz(:) / data.meas.sigma_fdoa; ...
            0];

    otherwise
        error('未知的约化回代模式：%s', mode_name);
end

theta = A \ b;

radio = struct( ...
    'fc0_hz', theta(1), ...
    'tx_drift_hz_s', theta(2), ...
    'rx1_bias_hz', 0, ...
    'rx1_drift_hz_s', 0, ...
    'rx2_bias_hz', 0, ...
    'rx2_drift_hz_s', 0);

info.theta = theta;
info.A = A;
info.b = b;
info.valid = is_valid_radio_state([x_geo(:).', theta(:).'], data);

if ~info.valid
    info.cost = 1e30;
    return;
end

pred = predict_radio_measurements(x_geo, radio, data);
switch lower(mode_name)
    case 'traditional'
        r1 = (data.z.f1_hz - pred.f1_hz) / data.meas.sigma_f1;
        r2 = (data.z.f2_hz - pred.f2_hz) / data.meas.sigma_f2;
        info.cost = sum(r1.^2) + sum(r2.^2) + (theta(2) / 0.05)^2;

    case 'fdoa'
        r = (data.z.fdoa_hz - pred.fdoa_hz) / data.meas.sigma_fdoa;
        info.cost = sum(r.^2) + (theta(2) / 0.05)^2;
end
end

function radio = unit_radio()
% 用 fc0=1、频漂=0 构造单位频率模型，便于提取线性设计矩阵。
radio.fc0_hz = 1;
radio.tx_drift_hz_s = 0;
radio.rx1_bias_hz = 0;
radio.rx1_drift_hz_s = 0;
radio.rx2_bias_hz = 0;
radio.rx2_drift_hz_s = 0;
end
