function [seed_list, score_list] = build_geo_seed_candidates_reduced(data, mode_name, top_k)
%==========================================================================
% 函数名称：build_geo_seed_candidates_reduced
% 功能说明：
%   基于指定量测体制，为 GEO 几何参数 [a, lambda0] 生成 Top-K 粗搜初值。
%   对传统非差和纯 FDOA，粗搜评分直接采用约化几何代价函数，
%   从而与后端“外层几何、内层频参回代”的求解口径保持一致。
%==========================================================================

if nargin < 3 || isempty(top_k)
    top_k = 5;
end

a_grid = data.const.geo_a_km + (-100:2:100);
lambda_grid = 70:0.5:160;

Ncand = numel(a_grid) * numel(lambda_grid);
geom_all = zeros(Ncand, 2);
score_all = inf(Ncand, 1);
idx = 0;

for ia = 1:numel(a_grid)
    for il = 1:numel(lambda_grid)
        idx = idx + 1;
        x_geo = [a_grid(ia), lambda_grid(il)];
        geom_all(idx, :) = x_geo;
        score_all(idx) = evaluate_seed_score(x_geo, data, mode_name);
    end
end

[score_sorted, order] = sort(score_all, 'ascend');
geom_sorted = geom_all(order, :);

top_k = min(top_k, size(geom_sorted, 1));
seed_list = geom_sorted(1:top_k, :);
score_list = score_sorted(1:top_k);
end

function score = evaluate_seed_score(x_geo, data, mode_name)
switch lower(mode_name)
    case 'traditional'
        score = reduced_traditional_geo_cost(x_geo, data);

    case 'fdoa'
        score = reduced_fdoa_geo_cost(x_geo, data);

    case 'froa'
        radio0 = estimate_initial_radio_params(x_geo, data, 'joint');
        radio0.fc0_hz = data.meas.fc_nominal_hz;
        pred = predict_radio_measurements(x_geo, radio0, data);
        r = (data.z.froa - pred.froa) / data.meas.sigma_froa;
        score = sum(r.^2);

    otherwise
        error('未知约化粗搜模式：%s', mode_name);
end
end
