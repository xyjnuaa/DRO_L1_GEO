function result = method_hybrid_fusion(data)
%==========================================================================
% 函数名称：method_hybrid_fusion
% 功能说明：
%   三阶段融合法：
%   1) 用 FROA 做几何粗筛；
%   2) 用 FROA + FDOA 做几何与频参的联合中间估计；
%   3) 固定在联合中间解附近，再用非差多普勒回代载频并做最终小范围联合微调。
%
% 说明：
%   该方法的设计目标不是让前端几何信息和后端载频信息互相抢解释权，
%   而是让 FROA/FDOA 先把几何约束收紧，再让非差多普勒发挥其对绝对载频更敏感的优势。
%==========================================================================
tic;
seed_geo = build_froa_screen_seed(data);
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0_joint = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];

opts_joint = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);



%---------------------- 阶段1：FROA+FDOA 联合中间估计 ----------------------
[x_mid, ~] = fminsearch(@(x) joint_fdoa_froa_cost_function(x, data), x0_joint, opts_joint);

%---------------------- 阶段2：固定几何后，用非差多普勒回代频参 ----------------------
geo_mid = x_mid(1:3);
radio_nd = estimate_initial_radio_params(geo_mid, data, 'traditional');
x0_final = [geo_mid, radio_nd.fc0_hz, radio_nd.tx_drift_hz_s];

%---------------------- 阶段3：在中间解附近做最终非差联合微调 ----------------------
[xhat, fval] = fminsearch(@(x) local_traditional_cost(x, data, x_mid), x0_final, opts_final);
elapsed = toc;

result.name = '三阶段融合法';
result.kind = 'fusion';
result.seed_geo = seed_geo;
result.x_mid = x_mid;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional');
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function J = local_traditional_cost(x, data, x_center)
% 在传统非差多普勒代价函数外加一个局部信任域项，避免最终阶段完全退化为传统法的全局搜索。
if any(abs(x(1:3) - x_center(1:3)) > [80, 1.0, 0.08])
    J = 1e30;
    return;
end
if abs(x(4) - x_center(4)) > 5e5
    J = 1e30;
    return;
end
if abs(x(5) - x_center(5)) > 0.05
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);
J = J + 0.2 * sum(((x(1:3) - x_center(1:3)) ./ [20, 0.2, 0.02]).^2);
end
