function result = method_pure_fdoa_reduced(data)
%==========================================================================
% 函数名称：method_pure_fdoa_reduced
% 功能说明：
%   纯 FDOA 方法的约化几何优化版本。
%   外层多起点优化几何 [a, lambda0]，内层线性回代 fc0 与频漂。
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates_reduced(data, 'fdoa', 5);
objfun = @(x_geo) reduced_fdoa_geo_cost(x_geo, data);
opts = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-8, ...
    'MaxFunEvals',2500, 'MaxIter',1800);

[xhat_geo, fval, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) seed_geo(:).', objfun, opts);
[radio_hat, ~] = solve_reduced_radio_params(xhat_geo, data, 'fdoa');
xhat = [xhat_geo(:).', radio_hat.fc0_hz, radio_hat.tx_drift_hz_s];
elapsed = toc;

result.name = '纯FDOA';
result.kind = 'fdoa';
result.seed_geo = best_seed;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'fdoa', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end
