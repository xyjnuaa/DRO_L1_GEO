function [J_prior, info] = geo_dynamics_weak_penalty(x_geo, data)
%==========================================================================
% 函数名称：geo_dynamics_weak_penalty
% 功能说明：
%   根据近 GEO 两体动力学关系，为 [a, lambda0, dlambda] 提供一个弱约束项。
%   这里不强制 dlambda 完全等于由 a 推导的漂移率，而是允许在给定标准差内偏离。
%==========================================================================

a_km = x_geo(1);
dlambda_deg_day = x_geo(3);
expected_dlambda_deg_day = geo_expected_dlambda_from_a(a_km, data.const);
sigma_deg_day = data.model.geo_dlambda_sigma_deg_day;

residual = (dlambda_deg_day - expected_dlambda_deg_day) / sigma_deg_day;
J_prior = residual.^2;

if nargout > 1
    info.expected_dlambda_deg_day = expected_dlambda_deg_day;
    info.sigma_deg_day = sigma_deg_day;
    info.normalized_residual = residual;
end
end
