function result = method_hybrid_fusion_nondiff_mid(data)
%==========================================================================
% 函数名称：method_hybrid_fusion_nondiff_mid
% 功能说明：
%   变体融合法：
%   1) 用 FROA 粗筛获得几何初值；
%   2) 第二阶段改为纯非差多普勒联合估计；
%   3) 第三阶段仍保持“非差回代 + 局部非差微调”不变。
%
% 说明：
%   该方法用于分析：若把三阶段融合法中“FROA+FDOA 联合中间估计”
%   改为“纯非差中间估计”，则它与传统非差法是否还存在本质差异。
%==========================================================================
tic;

% 阶段0：仍沿用原融合法的 FROA 粗筛初值
seed_geo = build_froa_screen_seed(data);
radio0 = estimate_initial_radio_params(seed_geo, data, 'traditional');
x0_mid = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];

opts_mid = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-8, ...
    'MaxFunEvals',4000, 'MaxIter',2500);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

% 阶段1：改为纯非差多普勒中间估计
[x_mid, ~] = fminsearch(@(x) traditional_cost_function(x, data), x0_mid, opts_mid);

% 阶段2：固定几何后再做一次非差回代
geo_mid = x_mid(1:3);
radio_nd = estimate_initial_radio_params(geo_mid, data, 'traditional');
x0_final = [geo_mid, radio_nd.fc0_hz, radio_nd.tx_drift_hz_s];

% 阶段3：保持局部非差微调
[xhat, fval] = fminsearch(@(x) local_traditional_cost_variant(x, data, x_mid), x0_final, opts_final);
elapsed = toc;

result.name = '融合法-第二阶段纯非差';
result.kind = 'fusion_nondiff_mid';
result.seed_geo = seed_geo;
result.x_mid = x_mid;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional');
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function J = local_traditional_cost_variant(x, data, x_center)
if any(abs(x(1:3) - x_center(1:3)) > [80, 1.0, 0.08])
    J = 1e30;
    return;
end
if abs(x(4) - x_center(4)) > 5e5
    J = 1e30;
    return;
end
if abs(x(5) - x_center(5)) > 0.05
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);
J = J + 0.2 * sum(((x(1:3) - x_center(1:3)) ./ [20, 0.2, 0.02]).^2);
end
