function J = reduced_fdoa_geo_cost(x_geo, data)
%==========================================================================
% 函数名称：reduced_fdoa_geo_cost
% 功能说明：
%   纯 FDOA 方法的约化几何代价函数。
%   外层仅优化 [a, lambda0]，fc0 与频漂通过解析回代得到。
%==========================================================================

[~, info] = solve_reduced_radio_params(x_geo, data, 'fdoa');
J = info.cost;
end
