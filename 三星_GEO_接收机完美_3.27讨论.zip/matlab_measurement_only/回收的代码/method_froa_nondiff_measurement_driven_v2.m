function result = method_froa_nondiff_measurement_driven_v2(data)
%==========================================================================
% 函数名称：method_froa_nondiff_measurement_driven_v2
% 功能说明：
%   FROA + 非差联合法的增强版本：
%   1) 先用 FROA 进行几何粗搜与局部优化，得到中间解
%   2) 再围绕该中间解构造若干邻域多初值
%   3) 对每个邻域初值分别执行非差多普勒局部优化
%   4) 取总代价最小的结果作为最终输出
%
% 设计目的：
%   给第二阶段非差优化更多“重新修正几何”的自由度，
%   避免它只是在 FROA 中间解附近做很小的补偿。
%==========================================================================
tic;

%--------------------------------------------------------------------------
% 第一步：基于 FROA 的粗搜与局部优化
%--------------------------------------------------------------------------
[seed_list, ~] = build_geo_seed_candidates(data, 'froa', 5);

opts_froa = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',4000, 'MaxIter',2500);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

[x_mid, ~, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_froa_stage_x0_v2(seed_geo, data), ...
    @(x) pure_froa_cost_function(x, data), opts_froa);

%--------------------------------------------------------------------------
% 第二步：围绕 FROA 中间解做邻域多初值非差优化
%--------------------------------------------------------------------------
geo_mid = x_mid(1:2);
radio_backup = estimate_initial_radio_params(geo_mid, data, 'traditional');
geo_seed_list = build_stage2_neighbor_geometries_v2(geo_mid, data);

xhat_best = [];
fval_best = inf;
best_stage2_seed = [];

for i = 1:size(geo_seed_list, 1)
    geo_seed = geo_seed_list(i, :);

    % 对每个邻域几何单独回代非差频参初值，
    % 防止所有第二阶段优化都共用同一组载频/频漂初值。
    radio_seed = estimate_initial_radio_params(geo_seed, data, 'traditional');
    if ~isfinite(radio_seed.fc0_hz) || ~isfinite(radio_seed.tx_drift_hz_s)
        radio_seed = radio_backup;
    end

    x0_final = [geo_seed, radio_seed.fc0_hz, radio_seed.tx_drift_hz_s];
    [xhat_i, fval_i] = fminsearch( ...
        @(x) local_traditional_cost_froa_nd_v2(x, data, x_mid), x0_final, opts_final);

    if fval_i < fval_best
        fval_best = fval_i;
        xhat_best = xhat_i;
        best_stage2_seed = geo_seed;
    end
end

elapsed = toc;

result.name = 'FROA+非差联合法';
result.kind = 'froa_nondiff';
result.seed_geo = best_seed;
result.stage2_seed_geo = best_stage2_seed;
result.x_mid = x_mid;
result.xhat = xhat_best;
result.est = unpack_estimate_vector(xhat_best, 'traditional', data);
result.fval = fval_best;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_froa_stage_x0_v2(seed_geo, data)
% FROA 阶段的局部优化初值：几何 + 发射机频漂
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.tx_drift_hz_s];
end

function geo_seed_list = build_stage2_neighbor_geometries_v2(geo_mid, data)
%--------------------------------------------------------------------------
% 围绕 FROA 中间解构造第二阶段非差优化的邻域多初值。
% 使用“中心点 + 半长轴扰动 + 经度扰动 + 小范围组合扰动”的简单形式。
%--------------------------------------------------------------------------
a0 = geo_mid(1);
lambda0 = geo_mid(2);

geo_seed_list = [
    a0,            lambda0;
    a0 - 20,       lambda0;
    a0 + 20,       lambda0;
    a0 - 40,       lambda0;
    a0 + 40,       lambda0;
    a0,            lambda0 - 0.2;
    a0,            lambda0 + 0.2;
    a0,            lambda0 - 0.4;
    a0,            lambda0 + 0.4;
    a0 - 20,       lambda0 - 0.2;
    a0 - 20,       lambda0 + 0.2;
    a0 + 20,       lambda0 - 0.2;
    a0 + 20,       lambda0 + 0.2
    ];

% 裁剪到当前全局搜索的合理范围内
geo_seed_list(:,1) = min(max(geo_seed_list(:,1), data.const.geo_a_km - 300), ...
    data.const.geo_a_km + 300);
geo_seed_list(:,2) = min(max(geo_seed_list(:,2), 70), 160);

% 去除重复初值，避免重复优化
geo_seed_list = unique(round(geo_seed_list, 6), 'rows', 'stable');
end

function J = local_traditional_cost_froa_nd_v2(x, data, x_center)
%--------------------------------------------------------------------------
% 第二阶段局部代价函数：
%   1) 以非差多普勒残差为主
%   2) 保留较宽的硬约束，避免解跑到明显无关的区域
%   3) 只加较弱的软约束，避免几何被 FROA 中间解锁死
%--------------------------------------------------------------------------
if any(abs(x(1:2) - x_center(1:2)) > [150, 1.5])
    J = 1e30;
    return;
end
if abs(x(4) - x_center(3)) > 0.08
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);

% 软约束只做轻微引导，让第二阶段保留继续修正几何的能力
J = J + 0.001 * sum(((x(1:2) - x_center(1:2)) ./ [40, 0.4]).^2);
end
