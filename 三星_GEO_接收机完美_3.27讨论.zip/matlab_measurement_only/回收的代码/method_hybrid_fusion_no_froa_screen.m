function result = method_hybrid_fusion_no_froa_screen(data)
%==========================================================================
% 函数名称：method_hybrid_fusion_no_froa_screen
% 功能说明：
%   三阶段融合法的消融版本：
%   不使用 FROA 粗筛，而是采用通用粗搜作为前端初值。
%==========================================================================
tic;
seed_geo = build_common_geo_seed(data);
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0_joint = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];

opts_joint = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);


[x_mid, ~] = fminsearch(@(x) joint_fdoa_froa_cost_function(x, data), x0_joint, opts_joint);

geo_mid = x_mid(1:2);
radio_nd = estimate_initial_radio_params(geo_mid, data, 'traditional');
x0_final = [geo_mid, radio_nd.fc0_hz, radio_nd.tx_drift_hz_s];

[xhat, fval] = fminsearch(@(x) local_traditional_cost_no_screen(x, data, x_mid), x0_final, opts_final);
elapsed = toc;

result.name = '三阶段融合-无FROA粗筛';
result.kind = 'fusion_no_screen';
result.seed_geo = seed_geo;
result.x_mid = x_mid;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function J = local_traditional_cost_no_screen(x, data, x_center)
if any(abs(x(1:2) - x_center(1:2)) > [80, 1.0])
    J = 1e30;
    return;
end
if abs(x(3) - x_center(3)) > 5e5
    J = 1e30;
    return;
end
if abs(x(4) - x_center(4)) > 0.05
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);
J = J + 0.2 * sum(((x(1:2) - x_center(1:2)) ./ [20, 0.2]).^2);
end
