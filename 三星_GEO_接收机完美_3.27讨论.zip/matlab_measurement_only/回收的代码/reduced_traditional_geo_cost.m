function J = reduced_traditional_geo_cost(x_geo, data)
%==========================================================================
% 函数名称：reduced_traditional_geo_cost
% 功能说明：
%   传统非差多普勒的约化几何代价函数。
%   外层仅优化 [a, lambda0]，fc0 与频漂通过解析回代得到。
%==========================================================================

[~, info] = solve_reduced_radio_params(x_geo, data, 'traditional');
J = info.cost;
end
