function result = method_joint_measurement_driven(data)
%==========================================================================
% 函数名称：method_joint_measurement_driven
% 功能说明：
%   联合法，采用基于 FDOA+FROA 联合量测的 Top-K 多起点粗搜。
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates(data, 'joint', 5);
objfun = @(x) joint_fdoa_froa_cost_function(x, data);
opts = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

[xhat, fval, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_joint_x0(seed_geo, data), objfun, opts);
elapsed = toc;

result.name = '联合法';
result.kind = 'joint';
result.seed_geo = best_seed;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'joint', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_joint_x0(seed_geo, data)
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];
end
