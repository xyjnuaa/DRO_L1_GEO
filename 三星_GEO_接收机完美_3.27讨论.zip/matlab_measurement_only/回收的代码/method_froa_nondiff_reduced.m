function result = method_froa_nondiff_reduced(data)
%==========================================================================
% 函数名称：method_froa_nondiff_reduced
% 功能说明：
%   FROA + 非差联合法的简化增强版：
%   1) 先用 FROA 单一路径完成几何粗搜与局部优化
%   2) 再从该几何出发，做非差约化几何优化
%      外层只优化 [a, lambda0]，内层线性回代 fc0 与频漂
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates_reduced(data, 'froa', 1);
best_seed = seed_list(1, :);

opts_froa = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',4000, 'MaxIter',2500);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

x0_froa = build_froa_stage_x0(best_seed, data);
[x_mid, ~] = fminsearch(@(x) pure_froa_cost_function(x, data), x0_froa, opts_froa);

geo_mid = x_mid(1:2);
[geo_hat, fval] = fminsearch(@(x_geo) reduced_traditional_geo_cost(x_geo, data), ...
    geo_mid, opts_final);
[radio_hat, ~] = solve_reduced_radio_params(geo_hat, data, 'traditional');
xhat = [geo_hat(:).', radio_hat.fc0_hz, radio_hat.tx_drift_hz_s];
elapsed = toc;

result.name = 'FROA+非差联合法';
result.kind = 'froa_nondiff';
result.seed_geo = best_seed;
result.x_mid = x_mid;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_froa_stage_x0(seed_geo, data)
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.tx_drift_hz_s];
end
