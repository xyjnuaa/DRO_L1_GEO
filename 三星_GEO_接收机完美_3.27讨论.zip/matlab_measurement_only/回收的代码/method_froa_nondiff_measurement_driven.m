function result = method_froa_nondiff_measurement_driven(data)
%==========================================================================
% 函数名称：method_froa_nondiff_measurement_driven
% 功能说明：
%   FROA + 非差联合法：
%   1) 先使用 FROA 量测完成几何粗搜与局部优化
%   2) 再在该几何附近用非差多普勒回代载频和频漂，并做局部微调
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates(data, 'froa', 10);
opts_froa = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',4000, 'MaxIter',2500);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

[x_mid, ~, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_froa_stage_x0(seed_geo, data), ...
    @(x) pure_froa_cost_function(x, data), opts_froa);

geo_mid = x_mid(1:2);
radio_nd = estimate_initial_radio_params(geo_mid, data, 'traditional');
x0_final = [geo_mid, radio_nd.fc0_hz, radio_nd.tx_drift_hz_s];

[xhat, fval] = fminsearch(@(x) local_traditional_cost_froa_nd(x, data, x_mid), ...
    x0_final, opts_final);
elapsed = toc;

result.name = 'FROA+非差联合法';
result.kind = 'froa_nondiff';
result.seed_geo = best_seed;
result.x_mid = x_mid;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function x0 = build_froa_stage_x0(seed_geo, data)
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.tx_drift_hz_s];
end

function J = local_traditional_cost_froa_nd(x, data, x_center)
if any(abs(x(1:2) - x_center(1:2)) > [150, 1.5])
    J = 1e30;
    return;
end
if abs(x(4) - x_center(3)) > 0.05
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);
J = J + 0.001 * sum(((x(1:2) - x_center(1:2)) ./ [40, 0.4]).^2);
end
