function result = method_hybrid_fusion_measurement_driven(data)
%==========================================================================
% 函数名称：method_hybrid_fusion_measurement_driven
% 功能说明：
%   三阶段融合法，第一阶段采用联合量测 Top-K 多起点粗搜，
%   第二阶段做联合估计，第三阶段做非差多普勒局部回代与微调。
%==========================================================================
tic;

[seed_list, ~] = build_geo_seed_candidates(data, 'joint', 5);
opts_joint = optimset('Display','off', 'TolX',1e-6, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);
opts_final = optimset('Display','off', 'TolX',1e-7, 'TolFun',1e-10, ...
    'MaxFunEvals',3000, 'MaxIter',2000);

[x_mid, ~, best_seed] = run_multistart_measurement_fit( ...
    seed_list, @(seed_geo) build_fusion_joint_x0(seed_geo, data), ...
    @(x) joint_fdoa_froa_cost_function(x, data), opts_joint);

geo_mid = x_mid(1:2);
radio_nd = estimate_initial_radio_params(geo_mid, data, 'traditional');
x0_final = [geo_mid, radio_nd.fc0_hz, radio_nd.tx_drift_hz_s];

[xhat, fval] = fminsearch(@(x) local_traditional_cost_ms(x, data, x_mid), x0_final, opts_final);
elapsed = toc;

result.name = '三阶段融合法';
result.kind = 'fusion';
result.seed_geo = best_seed;
result.x_mid = x_mid;
result.xhat = xhat;
result.est = unpack_estimate_vector(xhat, 'traditional', data);
result.fval = fval;
result.time_sec = elapsed;
result.success = true;
end

function J = local_traditional_cost_ms(x, data, x_center)
if any(abs(x(1:2) - x_center(1:2)) > [80, 1.0])
    J = 1e30;
    return;
end
if abs(x(3) - x_center(3)) > 5e5
    J = 1e30;
    return;
end
if abs(x(4) - x_center(4)) > 0.05
    J = 1e30;
    return;
end

J = traditional_cost_function(x, data);
J = J + 0.2 * sum(((x(1:2) - x_center(1:2)) ./ [20, 0.2]).^2);
end

function x0 = build_fusion_joint_x0(seed_geo, data)
radio0 = estimate_initial_radio_params(seed_geo, data, 'joint');
x0 = [seed_geo(:).', radio0.fc0_hz, radio0.tx_drift_hz_s];
end
