function [xhat_best, fval_best, best_seed] = run_multistart_measurement_fit(seed_list, x0_builder, objfun, opts)
%==========================================================================
% 函数名称：run_multistart_measurement_fit
% 功能说明：
%   针对一组粗搜初值逐一执行局部优化，并返回总代价最小的结果。
%==========================================================================

fval_best = inf;
xhat_best = [];
best_seed = [];

for i = 1:size(seed_list, 1)
    x0 = x0_builder(seed_list(i, :));
    [xhat_i, fval_i] = fminsearch(objfun, x0, opts);
    if fval_i < fval_best
        fval_best = fval_i;
        xhat_best = xhat_i;
        best_seed = seed_list(i, :);
    end
end

if isempty(xhat_best)
    error('多起点局部优化未产生有效解。');
end
end
