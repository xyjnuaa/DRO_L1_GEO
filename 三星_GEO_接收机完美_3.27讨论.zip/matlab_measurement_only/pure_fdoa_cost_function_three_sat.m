function J = pure_fdoa_cost_function_three_sat(x, data)
% 三颗观测星下的纯 FDOA 目标函数
if ~is_valid_radio_state(x(1:4), data)
    J = 1e30;
    return;
end

x_geo = x(1:2);
radio.fc0_hz = x(3);
radio.tx_drift_hz_s = x(4);
radio.rx1_bias_hz = 0;
radio.rx1_drift_hz_s = 0;
radio.rx2_bias_hz = 0;
radio.rx2_drift_hz_s = 0;
radio.rx3_bias_hz = 0;
radio.rx3_drift_hz_s = 0;

pred = predict_radio_measurements_three_sat(x_geo, radio, data);
res = (data.z.fdoa_hz - pred.fdoa_hz) / data.meas.sigma_fdoa;
J = sum(res(:).^2);
J = J + (x(4) / 0.05)^2;
end
