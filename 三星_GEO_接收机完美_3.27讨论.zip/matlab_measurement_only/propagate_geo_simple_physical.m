function [r_km, v_kms] = propagate_geo_simple_physical(truth, t_sec, const)
%==========================================================================
% 函数名称：propagate_geo_simple_physical
% 功能说明：
%   基于两体近似的 GEO 简化传播模型。
%
% 说明：
%   该模型只把半长轴和初始经度作为主几何参数：
%   1) 轨道平均角速度由半长轴唯一决定
%   2) 地固经度漂移率由 n - wE 派生
%   3) 不再把漂移率作为独立传播输入
%==========================================================================

if isfield(truth, 'a_km')
    a_km = truth.a_km;
else
    a_km = truth.a;
end

lambda0_rad = deg2rad(truth.lambda0_deg);
n_orb = geo_mean_motion_j2(a_km, const);

% 用 J2 一致的圆轨道速度构造初始惯性系状态
r0_km = a_km * [cos(lambda0_rad); sin(lambda0_rad); 0];
v0_kms = a_km * n_orb * [-sin(lambda0_rad); cos(lambda0_rad); 0];

[r_km, v_kms] = propagate_orbit_j2_rk4(r0_km, v0_kms, t_sec, const);
end
