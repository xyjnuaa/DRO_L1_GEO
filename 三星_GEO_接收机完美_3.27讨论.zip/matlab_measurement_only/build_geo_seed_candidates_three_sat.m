function [seed_list, score_list] = build_geo_seed_candidates_three_sat(data, mode_name, top_k)
%==========================================================================
% 在三颗观测星配置下，为 GEO 几何参数 [a, lambda0] 生成 Top-K 粗搜初值
%==========================================================================

if nargin < 3 || isempty(top_k)
    top_k = 5;
end

a_grid = data.const.geo_a_km + (-100:2:100);
lambda_grid = 70:0.5:160;

Ncand = numel(a_grid) * numel(lambda_grid);
geom_all = zeros(Ncand, 2);
score_all = inf(Ncand, 1);
idx = 0;

for ia = 1:numel(a_grid)
    for il = 1:numel(lambda_grid)
        idx = idx + 1;
        x_geo = [a_grid(ia), lambda_grid(il)];
        geom_all(idx,:) = x_geo;
        score_all(idx) = evaluate_seed_score_three_sat(x_geo, data, mode_name);
    end
end

[score_sorted, order] = sort(score_all, 'ascend');
geom_sorted = geom_all(order,:);

top_k = min(top_k, size(geom_sorted, 1));
seed_list = geom_sorted(1:top_k,:);
score_list = score_sorted(1:top_k);
end

function score = evaluate_seed_score_three_sat(x_geo, data, mode_name)
switch lower(mode_name)
    case 'traditional'
        radio0 = estimate_initial_radio_params_three_sat(x_geo, data, 'traditional');
        pred = predict_radio_measurements_three_sat(x_geo, radio0, data);
        r1 = (data.z.f1_hz - pred.f1_hz) / data.meas.sigma_f1;
        r2 = (data.z.f2_hz - pred.f2_hz) / data.meas.sigma_f2;
        r3 = (data.z.f3_hz - pred.f3_hz) / data.meas.sigma_f3;
        score = sum(r1.^2) + sum(r2.^2) + sum(r3.^2);

    case 'fdoa'
        radio0 = estimate_initial_radio_params_three_sat(x_geo, data, 'fdoa');
        pred = predict_radio_measurements_three_sat(x_geo, radio0, data);
        r = (data.z.fdoa_hz - pred.fdoa_hz) / data.meas.sigma_fdoa;
        score = sum(r(:).^2);

    case 'froa'
        radio0.fc0_hz = data.meas.fc_nominal_hz+3600;
        radio0.tx_drift_hz_s = 1;
        radio0.rx1_bias_hz = 0;
        radio0.rx1_drift_hz_s = 1;
        radio0.rx2_bias_hz = 0;
        radio0.rx2_drift_hz_s = 0.95;
        radio0.rx3_bias_hz = 0;
        radio0.rx3_drift_hz_s = 1.5;
        pred = predict_radio_measurements_three_sat(x_geo, radio0, data);
        r = (data.z.froa - pred.froa) / data.meas.sigma_froa;
        score = sum(r(:).^2);

    otherwise
        error('未知粗搜模式：%s', mode_name);
end
end
